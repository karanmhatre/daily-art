@extends('layouts.master')

@section('content')

	@foreach ($themes as $theme)
		<div class="day_container">
			<div class="row">
				<div class="large-12 columns">
					<h3 class="date"> {{ date('d M, Y', strtotime($theme->date)) }} | <span class="theme">{{ $theme->theme }}</span></h3>
				</div>
			</div>
			<div class="row">
				<ul class="clearing row" data-clearing >
					@foreach ($theme->art as $art)
						<li class="large-6 columns"><a class="single_image" href="{{ URL::asset($art->image) }}">{{ HTML::image($art->image, $art->caption) }}</a><div class="meta">{{ $art->user->name }}</div></li>	
					@endforeach
				</ul>
			</div>
		</div>	
	@endforeach	
@stop
